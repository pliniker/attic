//
// useful numbers which shouldn't change more than once
//

package uk.ac.ic.doc.ise3.cart3;


public class Const {

    public static int ourId;
    public static int accountNo;

    public static int xdim;
    public static int ydim;

    // reinforcement data file extension
    public static String fileExt;

	// variable objects
	public static Var scalingFactor = new Var(1.0f);
	public static Var learningRate = new Var(1.0f);
	public static Var interSellT = new Var(5000.0f);
	public static Var maxContracts = new Var(3.0f);
	public static Var interContractT = new Var(5000.0f);
}
