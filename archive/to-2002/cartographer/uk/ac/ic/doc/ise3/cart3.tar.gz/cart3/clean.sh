#!/bin/sh

rm *.class *~
