//
// class SellMonkey
//
// sells bananas
//

package uk.ac.ic.doc.ise3.cart3;   
import uk.ac.ic.doc.ise3.sp.*;   
  


public class SellMonkey extends Thread {


    //
    // called by Comms on sale/non-sale of Lot
    //
    public synchronized void result(Lot l, int outcome) {
    }


    //
    // sell things thread
    //
    public void run() {
    }


    //
    //
    //
    public SellMonkey() {
    }

}


/*
			switch (reason) {
			case AuctionServer.YOU_SOLD_LOT: {

				// update Reinfo stuff
				Vector v = lot.getAllBids();
				for (int i = 0; i < v.size(); i++) {
					Bid n = (Bid)v.get(i);
		    
					// add any new cartographers to list
					Const.addCart(n.getID());
		    
					// update knowledge
					Reinfo r = run.creditman.getCartographer(n.getID());
					Area a = new Area(lot.getRegion());
					float updt = (float)n.getAmount() * (1000.0f / (float)lot.getAccuracy()) * ((float)(Const.xdim * Const.ydim) / (float)a.area());
					r.update((int)updt);
				}
		
				Bid b = Const.getwinner_id(lot);
				run.creditman.outcome(lot);
				run.creditman.addTransaction(b.getID(), -Const.getwinner_amt(lot));
				run.mapman.updateMap(b.getID(), lot.getRegion(), lot.getAccuracy());
		
				run.gui.println("Comms: sold lot " + lot.getLotNo());
				break; }
			default:
				run.gui.println("Comms: unsold lot " + lot.getLotNo());
			}
*/
