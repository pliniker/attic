//
// class ContractMonkey
//
// bananas
//

package uk.ac.ic.doc.ise3.cart3;   
import uk.ac.ic.doc.ise3.sp.*;   
  


public class ContractMonkey extends Thread {


    //
    // contract has been delivered
    //
    public synchronized void deliver(Region r, int acc) {
    }


    //
    // choose one from the few
    //
    public synchronized Quote pickQuote(Vector quotes) {
    }


    //
    //
    //
    public void run() {
    }


	//
	// a general contract has been made by another cartographer
	//
	public void contractMade(int cartID, int robotID, Quote quote) {
		//run.mapman.updateMap(cartID, quote.getRegion(), quote.getAccuracy());
		//run.creditman.addTransaction(cartID, - quote.getPrice());
	}


    //
    //
    //
    public ContractMonkey() {
    }

}


/*

		run.mapman.updateMap(Const.ourId,r, accuracy);
		Area a = new Area(r);
		run.mapman.unlockArea(a);
		run.contractman.down();
		run.gui.println("Comms: received region from robot");
*/
