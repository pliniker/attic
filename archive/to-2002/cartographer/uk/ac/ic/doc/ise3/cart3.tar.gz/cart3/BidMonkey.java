//
// class BidMonkey
//
// bids for bananas
//


package uk.ac.ic.doc.ise3.cart3;  
import uk.ac.ic.doc.ise3.sp.*;  
 


public class BidMonkey {


    //
    // called by Comms when we win
    //
    public synchronized void win(Lot lot) {
    }


    //
    // called by Comms when we lose
    //    
    public synchronized void lose(Lot lot) {
    }
    

    //
    // called by Comms on new auction
	// returns price
    //
    public synchronized int newAuction(Lot lot) {
    }


    //
    // 
    //
    public BidMonkey() {
	
    }
}

/*
			// if we won and wanted to lose...
			Bid b = Const.getwinner_id(lot);
			int amt = Const.getwinner_amt(lot);

			if (lot.getAccuracy() < Const.accuracyThreshold) {
				Area a = new Area(lot.getRegion());
				float updt = (float)amt * (1000.0f / (float)lot.getAccuracy()) * ((float)(Const.xdim * Const.ydim) / (float)a.area());
				run.creditman.self.update((int)updt);
			}
	    
			// update Reinfo stuff
			Vector v = lot.getAllBids();
			for (int i = 0; i < v.size(); i++) {
				Bid n = (Bid)v.get(i);
		
				if (n.getID() == Const.ourId) { continue; }
		
				// add any new cartographers to list
				Const.addCart(n.getID());
		
				// update knowledge
				Reinfo r = run.creditman.getCartographer(n.getID());
				Area a = new Area(lot.getRegion());
				float updt = (float)n.getAmount() * (1000.0f / (float)lot.getAccuracy()) * ((float)(Const.xdim * Const.ydim) / (float)a.area());
				r.update((int)updt);
			}
	    
			// newly acquired region.
			run.mapman.updateMap(Const.ourId, lot.getRegion(), lot.getAccuracy());
			run.creditman.outcome(lot);
			run.creditman.addTransaction(Const.ourId, -amt);
	    
			run.gui.println("Comms: won auction " + lot.getLotNo());
*/

/*
			// update Reinfo stuff
			Vector v = lot.getAllBids();
			for (int i = 0; i < v.size(); i++) {
				Bid n = (Bid)v.get(i);
		
				if (n.getID() == Const.ourId) { continue; }
		
				// add any new cartographers to list
				Const.addCart(n.getID());
		
				// update knowledge
				Reinfo r = run.creditman.getCartographer(n.getID());
				Area a = new Area(lot.getRegion());
				float updt = (float)n.getAmount() * (1000.0f / (float)lot.getAccuracy()) * ((float)(Const.xdim * Const.ydim) / (float)a.area());
				r.update((int)updt);
			}
	    
			Bid b = Const.getwinner_id(lot);
			int pay = Const.getwinner_amt(lot);
	    
			Area a = new Area(lot.getRegion());
			float updt;
			if (lot.getAccuracy() >= Const.accuracyThreshold) {
				// if we wanted to win, then that was bad
				updt = (float)b.getAmount() * (1000.0f / (float)lot.getAccuracy()) * ((float)(Const.xdim * Const.ydim) / (float)a.area());
			} else {
				// otherwise good - adjust so next time we bid what they pay
				int lowerbid = pay;
				updt = (float)lowerbid * (1000.0f / (float)lot.getAccuracy()) * ((float)(Const.xdim * Const.ydim) / (float)a.area());
			}
			run.creditman.self.update((int)updt);
	    
			// if all were below reserve...
			if (b.getID() != Const.ourId) {
				run.creditman.outcome(lot);
				run.creditman.addTransaction(b.getID(), - pay);
				run.mapman.updateMap(b.getID(), lot.getRegion(), lot.getAccuracy());
			}
	    
			run.gui.println("Comms: lost auction " + lot.getLotNo());
*/
